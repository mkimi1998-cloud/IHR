import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar as RNBar,
  StyleSheet,
  Text,
  TextInput,
  useColorScheme,
  View
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Location from 'expo-location';
import * as SecureStore from 'expo-secure-store';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImageManipulator from 'expo-image-manipulator';
import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { themes } from './src/theme';
import {
  EP,
  KERJA_LUAR_TYPES,
  addLocalTag,
  call,
  clearSession,
  deviceId,
  findPhoto,
  getLocalTags,
  kerjaLuarFields,
  loadSession,
  matchReasons,
  saveDeviceId,
  saveSession,
  unwrap
} from './src/api';

const pad = (n) => String(n).padStart(2, '0');
const t12 = (h, m) => `${pad(h % 12 || 12)}:${pad(m)} ${h < 12 ? 'AM' : 'PM'}`;
const fromServer = (v) => {
  const m = /(\d{4}-\d{2}-\d{2})[ T](\d{2}):(\d{2})/.exec(String(v || ''));
  return m ? t12(+m[2], +m[3]) : null;
};
const fromMs = (ms) => {
  const d = new Date(ms);
  return t12(d.getHours(), d.getMinutes());
};
const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
const parseYMD = (v) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v || '').trim());
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date();
};
const toYMD = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const toDMY = (v) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v || '').trim());
  return m ? `${m[3]}/${m[2]}/${m[1]}` : String(v || '');
};
const ACTS = [[1, 'Kehadiran Biasa'], [2, 'BDR'], [3, 'Kerja Luar']];
const PORTAL = 'https://ihr.mtib.gov.my/user/leave_attendance/attendance_record';
const wrapName = (n, max = 26) => {
  const out = [];
  let cur = '';
  String(n || '')
    .trim()
    .split(/\s+/)
    .forEach((w) => {
      if (cur && (cur + ' ' + w).length > max) {
        out.push(cur);
        cur = w;
      } else {
        cur = cur ? cur + ' ' + w : w;
      }
    });
  if (cur) out.push(cur);
  return out;
};
const colorOf = (c, fb) => {
  const v = String(c ?? '').trim();
  return /^[0-9a-f]{6}$/i.test(v) ? '#' + v : v || fb;
};

const saveTagDetails = async (method, lat, lng) => {
  try {
    const d = new Date();
    const key = `TAG_DETAILS_${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const cur = JSON.parse((await SecureStore.getItemAsync(key)) || '[]');
    let address = 'Sedang memproses lokasi...';

    if (lat && lng) {
      try {
        const rev = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
        if (rev && rev.length > 0) {
          const r = rev[0];
          address = [r.name, r.street, r.city, r.subregion].filter(Boolean).join(', ');
        } else {
          address = 'Lokasi tidak dapat dikenal pasti';
        }
      } catch (err) {
        address = 'Gagal memuat turun nama lokasi';
      }
    } else {
      address = 'Koordinat GPS dimatikan / tidak tersedia';
    }

    cur.push({ t: Date.now(), m: method, lat, lng, address });
    await SecureStore.setItemAsync(key, JSON.stringify(cur));
  } catch (e) {
    console.log('Ralat simpan tag details:', e);
  }
};

const ThemeCtx = createContext(null);
const useT = () => useContext(ThemeCtx);

const Btn = ({ label, onPress, kind = 'main', busy, disabled, icon }) => {
  const { C, s } = useT();
  return (
    <Pressable
      onPress={onPress}
      disabled={busy || disabled}
      style={({ pressed }) => [
        s.btn,
        kind === 'ghost' && s.btnGhost,
        (busy || disabled) && { opacity: 0.5 },
        pressed && { opacity: 0.85 },
      ]}
    >
      {busy ? (
        <ActivityIndicator color={kind === 'ghost' ? C.primaryText : C.onPrimary} />
      ) : (
        <View style={s.btnIn}>
          {icon ? <Text style={s.btnIc}>{icon}</Text> : null}
          <Text style={[s.btnTx, kind === 'ghost' && { color: C.primaryText }]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
};

const Ico = ({ g, tint, size = 34 }) => {
  const { C } = useT();
  const t = tint || C.primary;
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.3,
        backgroundColor: t + '26',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ fontSize: size * 0.5 }}>{g}</Text>
    </View>
  );
};

const Card = ({ title, icon, tint, children }) => {
  const { s } = useT();
  return (
    <View style={s.card}>
      {title ? (
        <View style={s.cardH}>
          {icon ? <Ico g={icon} tint={tint} /> : null}
          <Text style={s.cardT}>{title}</Text>
        </View>
      ) : null}
      {children}
    </View>
  );
};

const Row = ({ icon, k, v, tint, last, selectable, stack }) => {
  const { s } = useT();
  return (
    <View style={[s.row, last && { borderBottomWidth: 0 }]}>
      {icon ? <Ico g={icon} tint={tint} size={28} /> : null}
      {stack ? (
        <View style={{ flex: 1 }}>
          <Text style={s.rowK}>{k}</Text>
          <Text style={[s.rowV, { textAlign: 'left', marginTop: 2 }]} selectable={selectable}>
            {v}
          </Text>
        </View>
      ) : (
        <>
          <Text style={s.rowK}>{k}</Text>
          <Text style={s.rowV} selectable={selectable}>
            {v}
          </Text>
        </>
      )}
    </View>
  );
};

const Collapse = ({ title, icon, tint, summary, strong, warn, open, onToggle, children }) => {
  const { C, s } = useT();
  return (
    <View style={s.card}>
      <Pressable onPress={onToggle} style={s.cardH} hitSlop={4}>
        {icon ? <Ico g={icon} tint={tint} /> : null}
        <View style={{ flex: 1 }}>
          <Text style={s.cardT}>{title}</Text>
          {!open && summary ? (
            <Text
              numberOfLines={1}
              style={{
                color: warn ? C.bad : strong ? C.ink : C.mute,
                fontSize: 13,
                fontWeight: strong ? '600' : '400',
                marginTop: 2,
              }}
            >
              {summary}
            </Text>
          ) : null}
        </View>
        <Text style={{ color: C.mute }}>{open ? '▲' : '▼'}</Text>
      </Pressable>
      {open ? children : null}
    </View>
  );
};

const Stat = ({ icon, label, value, tint, methodIcon, onPress }) => {
  const { s } = useT();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        s.stat,
        { backgroundColor: tint + '12', borderColor: tint + '30' },
        pressed && { opacity: 0.6, backgroundColor: tint + '25' },
      ]}
    >
      <View style={s.statH}>
        <Ico g={icon} tint={tint} size={26} />
        <Text style={[s.statL, { color: tint }]}>{label}</Text>
      </View>
      <View style={{ marginTop: 10 }}>
        <Text style={[s.statV, { marginTop: 0 }]}>{value}</Text>
        {methodIcon ? (
          <View style={{ marginTop: 8, flexDirection: 'row', alignItems: 'center' }}>
            {typeof methodIcon === 'string' ? (
              <Text style={{ fontSize: 24, opacity: 0.8 }}>{methodIcon}</Text>
            ) : (
              methodIcon
            )}
          </View>
        ) : null}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 14, gap: 4 }}>
        <MaterialIcons name="touch-app" size={14} color={tint} style={{ opacity: 0.8 }} />
        <Text style={{ fontSize: 10, color: tint, fontWeight: '700', opacity: 0.8 }}>Klik untuk info</Text>
      </View>
    </Pressable>
  );
};

const Err = ({ msg }) => {
  const { C, s } = useT();
  return msg ? (
    <View style={s.err}>
      <Text style={{ color: C.bad }}>{msg}</Text>
    </View>
  ) : null;
};
const Ok = ({ msg }) => {
  const { C, s } = useT();
  return msg ? (
    <View style={s.okBox}>
      <Text style={{ color: C.ok }}>{msg}</Text>
    </View>
  ) : null;
};

const Top = ({ title, onBack, onTitleLongPress }) => {
  const { C, s } = useT();
  return (
    <View style={s.top}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={12}
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: C.field,
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 1,
              borderColor: C.line,
            }}
          >
            <Text style={{ color: C.ink, fontSize: 24, lineHeight: 28, marginLeft: -2 }}>‹</Text>
          </Pressable>
        ) : null}
        <Pressable onLongPress={onTitleLongPress} delayLongPress={800}>
          <Text style={s.topT}>{title}</Text>
        </Pressable>
      </View>
    </View>
  );
};

const Select = ({ value, placeholder, options, onPick }) => {
  const { C, s } = useT();
  const [open, setOpen] = useState(false);
  return (
    <View style={{ gap: 6 }}>
      <Pressable onPress={() => setOpen(!open)} style={[s.in, s.sel]}>
        <Text style={{ color: value ? C.ink : C.mute, fontSize: 16, flex: 1 }}>{value || placeholder}</Text>
        <Text style={{ color: C.mute }}>{open ? '▲' : '▼'}</Text>
      </Pressable>
      {open ? (
        <View style={s.selList}>
          {options.map((o, i) => (
            <Pressable
              key={o}
              onPress={() => {
                onPick(o);
                setOpen(false);
              }}
              style={[
                s.selItem,
                i === options.length - 1 && { borderBottomWidth: 0 },
                o === value && { backgroundColor: C.primarySoft },
              ]}
            >
              <Text style={{ color: C.ink, fontSize: 16 }}>{o}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
    </View>
  );
};

const DateField = ({ value, onPick, min }) => {
  const { C, s } = useT();
  const open = () =>
    DateTimePickerAndroid.open({
      value: parseYMD(value),
      mode: 'date',
      minimumDate: min ? parseYMD(min) : undefined,
      onChange: (e, d) => {
        if (e?.type === 'set' && d) onPick(toYMD(d));
      },
    });
  return (
    <Pressable onPress={open} style={[s.in, s.sel]}>
      <Text style={{ color: C.ink, fontSize: 16, flex: 1 }}>{toDMY(value)}</Text>
      <Text style={{ fontSize: 16 }}>📅</Text>
    </Pressable>
  );
};

function Register({ onDone, initialName = '', initialNo = '' }) {
  const { C, s } = useT();
  const [name, setName] = useState(initialName);
  const [no, setNo] = useState(initialNo);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [dev, setDev] = useState(String(deviceId()));
  const [adv, setAdv] = useState(false);

  const formatName = (text) => text.replace(/\s+/g, ' ').trim();

  const cont = async () => {
    if (!no.trim()) return setErr('Sila masukkan nombor staff');
    await saveDeviceId(dev);
    const formattedName = formatName(name);
    const sess = { staff_no: no.trim(), staff_id: '', name: formattedName };
    await saveSession(sess);
    onDone(sess);
  };

  const submit = async () => {
    const formattedName = formatName(name);
    if (!formattedName || !no.trim()) return setErr('Sila masukkan nama dan nombor staff');
    setBusy(true);
    setErr('');
    if (initialNo && no.trim() === initialNo) {
      await saveDeviceId(dev);
      const sess = { staff_no: no.trim(), staff_id: '', name: formattedName };
      await saveSession(sess);
      setBusy(false);
      return onDone(sess);
    }
    try {
      await saveDeviceId(dev);
      const r = unwrap(await call(EP.register, { name: formattedName, staff_no: no.trim(), imei: deviceId() }));
      const sess = {
        staff_no: no.trim(),
        staff_id: r?.staff_id ?? r?.id ?? '',
        name: formatName(r?.name ?? formattedName),
      };
      await saveSession(sess);
      onDone(sess);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
      <View style={s.regTopCentered}>
        <Pressable onLongPress={() => setAdv(!adv)} delayLongPress={1500} style={{ alignItems: 'center' }}>
          <Image source={require('./assets/icon.png')} style={{ width: 90, height: 90, marginBottom: 12 }} resizeMode="contain" />
          <Text style={s.logo}>iHR</Text>
          <Text style={s.sub}>Lembaga Perindustrian Kayu Malaysia</Text>
        </Pressable>
      </View>
      <View style={{ padding: 16, gap: 14 }}>
        <Card title="Daftar Pengguna Baru" icon="👤" tint={C.navy}>
          <Text style={s.lbl}>Nama penuh</Text>
          <TextInput
            style={s.in}
            value={name}
            onChangeText={setName}
            placeholder="Seperti dalam kad pengenalan"
            placeholderTextColor={C.mute}
          />
          <Text style={s.lbl}>Nombor staff</Text>
          <TextInput
            style={s.in}
            value={no}
            onChangeText={setNo}
            autoCapitalize="characters"
            placeholder="Contoh: 01234"
            placeholderTextColor={C.mute}
          />
          <Err msg={err} />
          <Btn label={initialNo ? 'Log Masuk' : 'Daftar'} onPress={submit} busy={busy} />
        </Card>
        {adv ? (
          <Card title="Tetapan lanjutan" icon="⚙️" tint={C.navy}>
            <Text style={s.lbl}>ID peranti. Tukar hanya jika perlu guna ID yang sudah didaftarkan untuk telefon ini.</Text>
            <TextInput style={s.in} value={dev} onChangeText={setDev} autoCapitalize="none" autoCorrect={false} />
            <Btn kind="ghost" label="Sudah berdaftar - teruskan" onPress={cont} />
          </Card>
        ) : null}
        <Text style={s.hint}>Peranti ini akan didaftarkan bersama nombor staff anda.</Text>
      </View>
    </ScrollView>
  );
}

function Dashboard({ sess, go, onSess, onLogout }) {
  const { C, s } = useT();
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [online, setOnline] = useState(null);
  const [at, setAt] = useState('');
  const [tags, setTags] = useState([]);
  const [photo, setPhoto] = useState(null);
  const [badPhoto, setBadPhoto] = useState(false);
  const [tagDetails, setTagDetails] = useState([]);

  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  const h = now.getHours();
  const greeting = h < 12 ? 'Selamat Pagi' : h < 15 ? 'Selamat Tengah Hari' : h < 19 ? 'Selamat Petang' : 'Selamat Malam';

  const load = useCallback(async () => {
    setBusy(true);
    setErr('');
    try {
      const r = await call(EP.dashboard, { staff_no: sess.staff_no, staff_id: sess.staff_id });
      setData(r);
      setOnline(true);
      setAt(new Date().toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' }));

      setTags(await getLocalTags());
      const d = new Date();
      const detailKey = `TAG_DETAILS_${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      const detailsStr = await SecureStore.getItemAsync(detailKey);
      if (detailsStr) setTagDetails(JSON.parse(detailsStr));

      const p = findPhoto(r);
      if (p) {
        setPhoto(p);
        setBadPhoto(false);
      }
      const sd = r?.staff_data;
      if (sd?.staff_id && String(sd.staff_id) !== String(sess.staff_id)) {
        const ns = {
          staff_no: String(sd.staff_no ?? sess.staff_no),
          staff_id: String(sd.staff_id),
          name: sd.name || sess.name,
        };
        saveSession(ns);
        onSess && onSess(ns);
      }
    } catch (e) {
      setOnline(false);
      setErr(
        e.message.includes('HTTP 500')
          ? e.message + '\n\nPeranti ini belum dikaitkan dengan akaun di pelayan. ID peranti: ' + deviceId()
          : e.message
      );
    } finally {
      setBusy(false);
    }
  }, [sess]);

  useEffect(() => {
    load();
  }, [load]);

  const handleLogout = () => {
    Alert.alert('Daftar Keluar', 'Adakah anda pasti mahu kembali ke paparan pendaftaran?', [
      { text: 'Batal', style: 'cancel' },
      {
        text: 'Ya',
        onPress: async () => {
          await clearSession();
          onLogout(sess);
        },
      },
    ]);
  };

  const getMethodIcon = (m) => {
    if (m === 'qr') {
      return (
        <>
          <MaterialIcons name="qr-code-2" size={18} color={C.ink} style={{ opacity: 0.7 }} />
          <Text style={{ color: C.mute, fontSize: 12, marginLeft: 6, fontWeight: '600' }}>Imbas QR</Text>
        </>
      );
    }
    if (m === 'geo') {
      return (
        <>
          <MaterialIcons name="map" size={18} color={C.ink} style={{ opacity: 0.7 }} />
          <Text style={{ color: C.mute, fontSize: 12, marginLeft: 6, fontWeight: '600' }}>Geo Tagging</Text>
        </>
      );
    }
    return null;
  };

  const sd = data?.staff_data || {};
  const name = sd.name || sess.name || 'Pengguna';
  const hasSrv = !!data && ('first_tagging' in data || 'last_tagging' in data);

  let first = hasSrv ? fromServer(data.first_tagging) : null;
  let last = hasSrv ? fromServer(data.last_tagging) : null;
  let firstM = '';
  let lastM = '';

  if (!first && data?.msg?.clock_in) {
    const m = data.msg.clock_in.match(/\d{1,2}:\d{2}\s*(?:AM|PM)/i);
    if (m) first = m[0];
  }
  if (!last && data?.msg?.clock_out) {
    const m = data.msg.clock_out.match(/\d{1,2}:\d{2}\s*(?:AM|PM)/i);
    if (m) last = m[0];
  }

  if (tags.length > 0) {
    const minT = tags[0];
    const maxT = tags[tags.length - 1];
    if (!first) first = fromMs(minT.t);
    firstM = minT.m;
    const serverLastMs = data?.last_tagging ? new Date(data.last_tagging.replace(' ', 'T')).getTime() : 0;
    if (maxT.t > serverLastMs || !last) {
      last = fromMs(maxT.t);
      lastM = maxT.m;
    } else {
      lastM = maxT.m;
    }
  }

  const showTagInfo = (title, isFirst) => {
    const timeVal = isFirst ? first : last;
    const legacyMethod = isFirst ? firstM : lastM;
    const detail = isFirst ? tagDetails[0] : tagDetails[tagDetails.length - 1];
    if (!timeVal || timeVal === '—') {
      Alert.alert(title, 'Belum ada rekod kehadiran.');
      return;
    }

    if (detail) {
      const methodName = detail.m === 'qr' ? 'Imbas QR' : 'Geo Tagging';
      Alert.alert(
        `Maklumat ${title}`,
        `Kaedah: ${methodName}\nMasa: ${fromMs(detail.t)}\nLokasi: ${detail.address || 'Tidak diketahui'}`
      );
    } else if (legacyMethod) {
      const methodName = legacyMethod === 'qr' ? 'Imbas QR' : 'Geo Tagging';
      Alert.alert(
        `Maklumat ${title}`,
        `Kaedah: ${methodName}\nMasa: ${timeVal}\n\n*Lokasi terperinci tidak ditemui untuk sesi ini.*`
      );
    } else {
      Alert.alert(
        `Maklumat ${title}`,
        `Masa: ${timeVal}\n\nRekod ini disegerakkan daripada pelayan web. Maklumat lokasi peranti tidak tersedia.`
      );
    }
  };

  const ring = data ? colorOf(data.att_color, C.accent) : C.accent;

  return (
    <ScrollView contentContainerStyle={{ paddingBottom: 28 }}>
      <View style={s.dashTop}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View style={{ backgroundColor: '#fff', borderRadius: 8, padding: 2 }}>
            <Image source={require('./assets/icon.png')} style={{ width: 36, height: 36 }} resizeMode="contain" />
          </View>
          <Text style={{ color: C.ink, fontSize: 32, fontWeight: '800', letterSpacing: 0.5 }}>iHR</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Pressable onPress={handleLogout} style={s.status}>
            <View style={[s.dot, { backgroundColor: online == null ? C.mute : online ? C.ok : C.bad }]} />
            <Text style={s.statusT}>{online == null ? 'Menyemak…' : online ? `Dalam talian ${at}` : 'Luar talian'}</Text>
          </Pressable>
          <Pressable
            onPress={load}
            disabled={busy}
            hitSlop={10}
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              marginTop: 8,
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: C.field,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: C.line,
            }}
          >
            {busy ? (
              <ActivityIndicator size="small" color={C.primaryText} />
            ) : (
              <>
                <MaterialIcons name="sync" size={16} color={C.primaryText} />
                <Text style={{ fontSize: 12, color: C.primaryText, fontWeight: '700', marginLeft: 4 }}>Muat Semula</Text>
              </>
            )}
          </Pressable>
        </View>
      </View>
      <View style={s.profile}>
        <Pressable
          onLongPress={() =>
            Alert.alert(
              'Medan data pelayan',
              data
                ? `${Object.keys(data).join(', ')}\n\nstaff_data: ${Object.keys(sd).join(', ') || '-'}\n\nGambar: ${photo ? 'dijumpai' : 'tiada'}`
                : 'Tiada data'
            )
          }
        >
          <View style={[s.ring, { borderColor: ring }]}>
            <View style={s.ringIn}>
              {photo && !badPhoto ? (
                <Image
                  source={photo.startsWith('data:') ? { uri: photo } : { uri: photo, headers: { imei: String(deviceId()) } }}
                  style={s.ringImg}
                  resizeMode="cover"
                  onError={() => setBadPhoto(true)}
                />
              ) : (
                <Text style={s.ringT}>{name.trim()[0]?.toUpperCase() || 'I'}</Text>
              )}
            </View>
          </View>
        </Pressable>
        <View style={s.pNameBox}>
          <Text style={{ color: C.mute, fontSize: 16, fontWeight: '700', marginBottom: 4 }}>{greeting},</Text>
          {wrapName(name).map((l, i) => (
            <Text key={i} style={s.pName} numberOfLines={1}>
              {l}
            </Text>
          ))}
        </View>
        <View style={s.chips}>
          <View style={s.chip}>
            <Text style={s.chipT}>No. staff {sd.staff_no ?? sess.staff_no}</Text>
          </View>
        </View>
        {data ? (
          <View style={s.pill}>
            <Text style={s.pillT}>{data.msg?.clock_in || 'Belum ada rekod waktu masuk hari ini.'}</Text>
          </View>
        ) : null}
      </View>

      <View style={{ paddingHorizontal: 16, gap: 14 }}>
        <View
          style={{
            alignItems: 'center',
            backgroundColor: C.card,
            paddingVertical: 18,
            borderRadius: 20,
            borderWidth: 1,
            borderColor: C.line,
            shadowColor: '#000',
            shadowOpacity: 0.05,
            shadowRadius: 8,
            elevation: 2,
          }}
        >
          <Text style={{ fontSize: 38, fontWeight: '800', color: C.ink, letterSpacing: 1, fontVariant: ['tabular-nums'] }}>
            {now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: C.primary,
              fontWeight: '700',
              marginTop: 4,
              textTransform: 'uppercase',
              letterSpacing: 0.5,
            }}
          >
            {now.toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </Text>
        </View>

        <Err msg={err} />
        {busy && !data ? <ActivityIndicator color={C.primaryText} /> : null}
        {data ? (
          <Card title="Hari ini" icon="🗓" tint={C.navy}>
            <View style={s.statRow}>
              <Stat
                icon="📍"
                label="First Tagging"
                value={first || '—'}
                tint={C.primary}
                methodIcon={firstM ? getMethodIcon(firstM) : null}
                onPress={() => showTagInfo('First Tagging', true)}
              />
              <Stat
                icon="📌"
                label="Last Tagging"
                value={last || '—'}
                tint={C.navy}
                methodIcon={lastM ? getMethodIcon(lastM) : null}
                onPress={() => showTagInfo('Last Tagging', false)}
              />
            </View>
            {!hasSrv ? <Text style={s.note}>Masa tagging direkod daripada app ini sahaja.</Text> : null}
            <Pressable onPress={() => Linking.openURL(PORTAL)} hitSlop={8}>
              <Text style={s.link}>🌐 Lihat rekod kehadiran penuh di portal web ›</Text>
            </Pressable>
          </Card>
        ) : null}
        <View style={{ gap: 10 }}>
          <Btn icon="📍" label="Geo Tagging" onPress={() => go('geo')} />
          <Btn icon="📷" label="Imbas QR" onPress={() => go('qr')} />
        </View>
      </View>

      <View style={{ marginTop: 32, marginBottom: 10, alignItems: 'center' }}>
        <Text style={{ color: C.mute, fontSize: 12, fontWeight: '600' }}>Copyright © 2026 MTIB</Text>
      </View>
    </ScrollView>
  );
}

function useFix() {
  const [fix, setFix] = useState(null);
  const [err, setErr] = useState('');
  const get = useCallback(async () => {
    setErr('');
    const p = await Location.requestForegroundPermissionsAsync();
    if (p.status !== 'granted') return setErr('Tiada akses lokasi');
    try {
      const l = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setFix(l.coords);
    } catch {
      setErr('Peranti tidak dapat mengesan lokasi anda');
    }
  }, []);
  useEffect(() => {
    get();
  }, [get]);
  return { fix, err, get, setFix };
}

const Loc = ({ fix, err, get }) => {
  const { C } = useT();
  const [open, setOpen] = useState(false);
  const summary = fix
    ? `${fix.latitude.toFixed(5)}, ${fix.longitude.toFixed(5)} · ± ${Math.round(fix.accuracy || 0)} m`
    : err || 'Mengesan lokasi…';
  return (
    <Collapse
      title="Lokasi semasa"
      icon="🛰"
      tint={C.navy}
      summary={summary}
      warn={!fix && !!err}
      open={open}
      onToggle={() => setOpen(!open)}
    >
      {fix ? (
        <>
          <Row icon="🧭" k="Latitud" v={fix.latitude.toFixed(6)} tint={C.navy} />
          <Row icon="🧭" k="Longitud" v={fix.longitude.toFixed(6)} tint={C.navy} />
          <Row icon="🎯" k="Ketepatan" v={`± ${Math.round(fix.accuracy || 0)} m`} tint={C.primary} last />
        </>
      ) : (
        <Text style={{ color: C.mute }}>{err || 'Mengesan lokasi…'}</Text>
      )}
      <Err msg={fix ? '' : err} />
      <Btn kind="ghost" icon="🔄" label="Kesan semula" onPress={get} />
    </Collapse>
  );
};

function Cam({ mode, sess, back }) {
  const { C, s } = useT();
  const [perm, ask] = useCameraPermissions();
  const ref = useRef(null);
  const loc = useFix();
  const [shot, setShot] = useState(null);
  const [done, setDone] = useState(false);
  const [act, setAct] = useState(null);
  const [actOpen, setActOpen] = useState(false);
  const [sd, setSd] = useState(todayStr());
  const [ed, setEd] = useState(todayStr());
  const [klType, setKlType] = useState('');
  const [reason, setReason] = useState('');
  const [opts, setOpts] = useState(KERJA_LUAR_TYPES.map((label) => ({ label })));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [ok, setOk] = useState('');

  // Password-protected admin backdoor
  const [askPwd, setAskPwd] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [pwd, setPwd] = useState('');
  const [qrInput, setQrInput] = useState('');
  const [includeLoc, setIncludeLoc] = useState(true);

  useEffect(() => {
    if (perm && !perm.granted) ask();
  }, [perm]);

  useEffect(() => {
    if (mode !== 'photo') return undefined;
    let on = true;
    call(EP.reason, {})
      .then((r) => {
        const m = matchReasons(r);
        if (on && m) setOpts(m);
      })
      .catch(() => {});
    return () => {
      on = false;
    };
  }, [mode]);

  const base = { staff_id: sess.staff_id };
  const need = () => (sess.staff_id ? '' : 'ID staff belum dimuatkan. Kembali ke Dashboard dan tunggu data dimuat.');

  const onQr = async ({ data }) => {
    if (done) return;
    if (need()) return setErr(need());
    if (!data || !String(data).trim()) return setErr('Sila masukkan atau imbas kod QR yang sah');
    setDone(true);
    setBusy(true);
    setErr('');
    try {
      const lat = includeLoc ? loc.fix?.latitude : '';
      const lng = includeLoc ? loc.fix?.longitude : '';
      const r = await call(EP.qr, {
        ...base,
        method: 'qr',
        qr_code: String(data).trim(),
        latitude: lat,
        longitude: lng,
      });
      await addLocalTag('qr');
      await saveTagDetails('qr', lat, lng);
      setOk(typeof r === 'string' ? r : 'Imbasan QR berjaya.');
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const pickQrImage = async () => {
    setErr('');
    setOk('');
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets[0]?.uri) {
        setBusy(true);
        const uri = result.assets[0].uri;

        let scannedData = null;
        if (typeof CameraView?.scanFromURLAsync === 'function') {
          try {
            const results = await CameraView.scanFromURLAsync(uri, ['qr']);
            if (results && results.length > 0 && results[0]?.data) {
              scannedData = results[0].data;
            }
          } catch (_) {}
        }

        if (scannedData) {
          setQrInput(scannedData);
          setOk('Teks Kod QR berjaya diekstrak.');
        } else {
          setOk('Gambar telah dipilih. Sila semak teks kod QR jika perlu dimasukkan manual.');
        }
      }
    } catch (e) {
      setErr('Ralat membuka imej: ' + e.message);
    } finally {
      setBusy(false);
    }
  };

  const snap = async () => {
    const p = await ref.current?.takePictureAsync({ quality: 0.5 });
    if (p) {
      const resized = await ImageManipulator.manipulateAsync(
        p.uri,
        [{ resize: { width: 800 } }],
        { compress: 0.5, format: ImageManipulator.SaveFormat.JPEG, base64: true }
      );
      setShot(resized);
    }
  };

  const sendPhoto = () => {
    if (need()) return setErr(need());
    if (!act) {
      setActOpen(true);
      return setErr('Sila pilih jenis kehadiran');
    }
    if (!shot) return setErr('Sila muat naik gambar');
    if (!loc.fix) return setErr('Tiada akses lokasi');
    const payload = {
      ...base,
      activity_type: act,
      latitude: loc.fix.latitude,
      longitude: loc.fix.longitude,
      img: shot.base64,
    };
    if (act === 3) {
      if (!klType) return setErr('Sila pilih jenis kerja luar');
      if (!reason.trim()) return setErr('Sila isi alasan');
      if (ed < sd) return setErr('Tarikh akhir tidak boleh sebelum tarikh mula');
      payload.start_date = sd;
      payload.end_date = ed;
      Object.assign(payload, kerjaLuarFields(opts.find((o) => o.label === klType), reason.trim()));
    }
    const label = ACTS.find(([v]) => v === act)[1];
    Alert.alert('Sahkan penghantaran', `Rekod kehadiran "${label}" akan disimpan dalam sistem iHR.`, [
      { text: 'Batal', style: 'cancel' },
      {
        text: 'Hantar',
        onPress: async () => {
          setBusy(true);
          setErr('');
          try {
            const r = await call(EP.geotag, payload);
            await addLocalTag('geo');
            await saveTagDetails('geo', loc.fix.latitude, loc.fix.longitude);
            setOk(typeof r === 'string' ? r : 'Geotagging berjaya dihantar.');
          } catch (e) {
            setErr(e.message);
          } finally {
            setBusy(false);
          }
        },
      },
    ]);
  };

  if (!perm?.granted) {
    return (
      <View style={{ flex: 1 }}>
        <Top title="Kamera" onBack={back} />
        <View style={{ padding: 16, gap: 12 }}>
          <Text style={{ color: C.ink }}>Tiada akses kamera.</Text>
          <Btn label="Benarkan kamera" onPress={ask} />
        </View>
      </View>
    );
  }

  return (
    <ScrollView keyboardShouldPersistTaps="handled">
      <Top
        title={mode === 'qr' ? 'Imbas QR' : 'Geotagging'}
        onBack={back}
        onTitleLongPress={() => setAskPwd(!askPwd)}
      />

      {/* Password verification popup/panel */}
      {askPwd && !unlocked && (
        <View style={{ padding: 16, gap: 10, backgroundColor: C.field, borderBottomWidth: 1, borderColor: C.line }}>
          <Text style={[s.lbl, { fontWeight: '700', color: C.ink }]}>Kunci Admin</Text>
          <TextInput
            style={s.in}
            secureTextEntry
            placeholder="Masukkan kata laluan admin"
            placeholderTextColor={C.mute}
            value={pwd}
            onChangeText={(t) => {
              setPwd(t);
              if (t.trim() === 'Mtib@123') {
                setUnlocked(true);
                setAskPwd(false);
                setPwd('');
              }
            }}
            onSubmitEditing={() => {
              if (pwd.trim() === 'Mtib@123') {
                setUnlocked(true);
                setAskPwd(false);
                setPwd('');
              } else {
                Alert.alert('Ralat', 'Kata laluan salah');
                setPwd('');
              }
            }}
          />
          <Btn
            label="Sahkan"
            onPress={() => {
              if (pwd.trim() === 'Mtib@123') {
                setUnlocked(true);
                setAskPwd(false);
                setPwd('');
              } else {
                Alert.alert('Ralat', 'Kata laluan salah');
                setPwd('');
              }
            }}
          />
        </View>
      )}

      {/* Unlocked Admin Controls */}
      {unlocked && (
        <View style={{ padding: 16, gap: 10, backgroundColor: C.field, borderBottomWidth: 1, borderColor: C.line }}>
          {mode === 'qr' ? (
            <>
              <Text style={[s.lbl, { fontWeight: '700', color: C.ink }]}>Muat Naik / Masukkan Kod QR Manual</Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <View style={{ flex: 1 }}>
                  <TextInput
                    style={s.in}
                    placeholder="Teks Kod QR..."
                    placeholderTextColor={C.mute}
                    value={qrInput}
                    onChangeText={setQrInput}
                  />
                </View>
                <Pressable
                  onPress={pickQrImage}
                  style={[s.btn, { paddingHorizontal: 16, paddingVertical: 12, backgroundColor: C.navy, justifyContent: 'center' }]}
                >
                  <Text style={s.btnTx}>📁 Upload</Text>
                </Pressable>
              </View>

              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 }}>
                <Text style={[s.lbl, { color: C.ink, fontWeight: '600' }]}>Sertakan Koordinat Lokasi?</Text>
                <Pressable
                  onPress={() => setIncludeLoc(!includeLoc)}
                  style={[s.btn, { paddingVertical: 8, paddingHorizontal: 18, backgroundColor: includeLoc ? C.ok : C.mute }]}
                >
                  <Text style={s.btnTx}>{includeLoc ? 'ON' : 'OFF'}</Text>
                </Pressable>
              </View>

              <Btn label="Hantar QR" onPress={() => onQr({ data: qrInput })} disabled={!qrInput.trim()} />
            </>
          ) : (
            <>
              <Text style={[s.lbl, { fontWeight: '700', color: C.ink }]}>Kawalan Manual Koordinat GPS</Text>
              <Text style={s.lbl}>Manual Latitud</Text>
              <TextInput
                style={s.in}
                keyboardType="numeric"
                value={String(loc.fix?.latitude || '')}
                onChangeText={(t) => loc.setFix((f) => ({ ...f, latitude: parseFloat(t) || 0, accuracy: 1 }))}
              />
              <Text style={s.lbl}>Manual Longitud</Text>
              <TextInput
                style={s.in}
                keyboardType="numeric"
                value={String(loc.fix?.longitude || '')}
                onChangeText={(t) => loc.setFix((f) => ({ ...f, longitude: parseFloat(t) || 0, accuracy: 1 }))}
              />
            </>
          )}
        </View>
      )}

      <View style={{ padding: 16, gap: 14 }}>
        {shot ? (
          <Image source={{ uri: shot.uri }} style={s.cam} />
        ) : (
          <CameraView
            ref={ref}
            style={s.cam}
            facing={mode === 'qr' ? 'back' : 'front'}
            barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
            onBarcodeScanned={mode === 'qr' ? onQr : undefined}
          />
        )}

        {/* --- BUTTONS MOVED DIRECTLY BELOW CAMERA VIEW FOR GEOTAGGING --- */}
        {mode === 'photo' ? (
          shot ? (
            <View style={{ gap: 10 }}>
              <Btn icon="📤" label="Hantar gambar" onPress={sendPhoto} busy={busy} />
              <Btn
                kind="ghost"
                icon="🔄"
                label="Ambil semula"
                onPress={() => {
                  setShot(null);
                  setOk('');
                }}
              />
            </View>
          ) : (
            <Btn icon="📷" label="Ambil Gambar" onPress={snap} />
          )
        ) : null}

        <Loc {...loc} />

        {mode === 'photo' ? (
          <Collapse
            title="Jenis kehadiran"
            icon="🗂"
            tint={C.primary}
            summary={act ? ACTS.find(([v]) => v === act)[1] : 'Pilih jenis kehadiran'}
            strong={!!act}
            open={actOpen}
            onToggle={() => setActOpen(!actOpen)}
          >
            {ACTS.map(([v, l]) => (
              <Pressable
                key={v}
                onPress={() => {
                  setAct(v);
                  setActOpen(false);
                }}
                style={[s.opt, act === v && s.optOn]}
              >
                <Text style={{ color: act === v ? C.onPrimary : C.ink, fontWeight: '600' }}>{l}</Text>
              </Pressable>
            ))}
          </Collapse>
        ) : null}

        {mode === 'photo' && act === 3 ? (
          <Card title="Butiran Kerja Luar" icon="🧳" tint={C.primary}>
            <Text style={s.lbl}>Jenis Kerja Luar</Text>
            <Select value={klType} placeholder="Pilih Jenis Kerja Luar" options={opts.map((o) => o.label)} onPick={setKlType} />
            <Text style={s.lbl}>Alasan</Text>
            <TextInput
              style={[s.in, { minHeight: 48 }]}
              value={reason}
              onChangeText={setReason}
              placeholder="Nyatakan alasan"
              placeholderTextColor={C.mute}
              multiline
            />
            <Text style={s.lbl}>Tarikh Mula</Text>
            <DateField
              value={sd}
              min={todayStr()}
              onPick={(v) => {
                setSd(v);
                if (ed < v) setEd(v);
              }}
            />
            <Text style={s.lbl}>Tarikh Akhir</Text>
            <DateField value={ed} min={sd} onPick={setEd} />
          </Card>
        ) : null}

        <Err msg={err} />
        <Ok msg={ok} />

        {/* QR Mode Bottom Controls */}
        {mode === 'qr' && (
          done && !busy ? (
            <Btn
              kind="ghost"
              icon="🔄"
              label="Imbas semula"
              onPress={() => {
                setDone(false);
                setErr('');
                setOk('');
              }}
            />
          ) : (
            <Text style={s.hint}>{busy ? 'Menghantar…' : 'Halakan kamera ke kod QR.'}</Text>
          )
        )}
      </View>
    </ScrollView>
  );
}

export default function App() {
  const scheme = useColorScheme() === 'dark' ? 'dark' : 'light';
  const C = themes[scheme];
  const s = useMemo(() => makeStyles(C), [scheme]);
  const [sess, setSess] = useState(undefined);
  const [view, setView] = useState('home');
  const [logoutData, setLogoutData] = useState(null);

  useEffect(() => {
    loadSession().then(setSess);
  }, []);
  const home = () => setView('home');

  let body;
  if (sess === undefined) body = <View style={s.center}><ActivityIndicator size="large" color={C.primary} /></View>;
  else if (!sess)
    body = (
      <Register
        onDone={setSess}
        initialName={logoutData?.name || ''}
        initialNo={logoutData?.staff_no || ''}
      />
    );
  else if (view === 'qr') body = <Cam mode="qr" sess={sess} back={home} />;
  else if (view === 'geo') body = <Cam mode="photo" sess={sess} back={home} />;
  else
    body = (
      <Dashboard
        sess={sess}
        go={setView}
        onSess={setSess}
        onLogout={(oldSess) => {
          setLogoutData(oldSess);
          setSess(null);
        }}
      />
    );

  return (
    <ThemeCtx.Provider value={{ C, s, scheme }}>
      <SafeAreaView style={s.root}>
        <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} backgroundColor={C.bg} />
        {Platform.OS === 'android' ? <View style={{ height: RNBar.currentHeight || 0, backgroundColor: C.bg }} /> : null}
        {body}
      </SafeAreaView>
    </ThemeCtx.Provider>
  );
}

const makeStyles = (C) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: C.bg },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    logo: { color: C.ink, fontSize: 38, fontWeight: '800', letterSpacing: 0.5, textAlign: 'center' },
    sub: { color: C.mute, marginTop: 2, textAlign: 'center' },
    regTop: { flexDirection: 'row', alignItems: 'flex-start', padding: 20, paddingTop: 16 },
    regTopCentered: { alignItems: 'center', padding: 20, paddingTop: 30 },
    gear: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: C.card,
      borderWidth: 1,
      borderColor: C.line,
      alignItems: 'center',
      justifyContent: 'center',
    },
    gearOn: { borderColor: C.primary, backgroundColor: C.primarySoft },
    gearT: { fontSize: 20 },
    dashTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 10 },
    status: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: C.card,
      borderWidth: 1,
      borderColor: C.line,
      borderRadius: 16,
      paddingHorizontal: 12,
      paddingVertical: 6,
    },
    statusT: { color: C.ink, fontSize: 12, fontWeight: '600' },
    dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
    profile: { alignItems: 'center', paddingHorizontal: 20, paddingVertical: 18, gap: 12 },
    ring: { width: 150, height: 150, borderRadius: 75, borderWidth: 11, alignItems: 'center', justifyContent: 'center' },
    ringIn: {
      width: 112,
      height: 112,
      borderRadius: 56,
      backgroundColor: C.card,
      borderWidth: 1,
      borderColor: C.line,
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
    },
    ringImg: { width: '100%', height: '100%' },
    sel: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
    selList: { borderWidth: 1, borderColor: C.line, borderRadius: 12, backgroundColor: C.field, overflow: 'hidden' },
    selItem: { paddingVertical: 13, paddingHorizontal: 14, borderBottomWidth: 1, borderBottomColor: C.line },
    ringT: { color: C.primaryText, fontSize: 48, fontWeight: '800' },
    pNameBox: { alignItems: 'center' },
    pName: { color: C.ink, fontSize: 20, fontWeight: '700', textAlign: 'center' },
    chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
    chip: {
      backgroundColor: C.card,
      borderWidth: 1,
      borderColor: C.line,
      borderRadius: 14,
      paddingHorizontal: 12,
      paddingVertical: 5,
    },
    chipT: { color: C.ink, fontSize: 12, fontWeight: '600' },
    pill: { backgroundColor: C.pill, borderRadius: 22, paddingHorizontal: 18, paddingVertical: 10, alignSelf: 'stretch' },
    pillT: { color: C.navy, textAlign: 'center', fontWeight: '500' },
    top: { backgroundColor: C.card, padding: 16, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.line },
    topT: { color: C.ink, fontSize: 24, fontWeight: '800' },
    back: { color: C.primaryText, fontWeight: '600' },
    card: { backgroundColor: C.card, borderRadius: 16, padding: 14, gap: 10, borderWidth: 1, borderColor: C.line },
    cardH: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingBottom: 2 },
    cardT: { fontSize: 16, fontWeight: '700', color: C.ink },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      paddingVertical: 9,
      borderBottomWidth: 1,
      borderBottomColor: C.line,
    },
    rowK: { color: C.mute, flexShrink: 0 },
    rowV: { color: C.ink, fontWeight: '600', flex: 1, textAlign: 'right' },
    rowV2: { color: C.ink, fontWeight: '700', marginTop: 2 },
    statRow: { flexDirection: 'row', gap: 10 },
    stat: { flex: 1, borderWidth: 1, borderColor: C.line, borderRadius: 14, padding: 12, backgroundColor: C.field },
    statH: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    statL: { color: C.mute, fontSize: 12, fontWeight: '600', flexShrink: 1 },
    statV: { color: C.ink, fontSize: 22, fontWeight: '800', marginTop: 10 },
    note: { color: C.mute, fontSize: 12 },
    link: { color: C.primaryText, fontWeight: '700', paddingTop: 4 },
    swatchRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
    swatch: { width: 40, height: 40, borderRadius: 20, borderWidth: 1, borderColor: C.line },
    lbl: { color: C.mute, fontSize: 13 },
    in: {
      borderWidth: 1,
      borderColor: C.line,
      borderRadius: 12,
      padding: 12,
      fontSize: 16,
      backgroundColor: C.field,
      color: C.ink,
    },
    btn: {
      backgroundColor: C.primary,
      borderRadius: 28,
      paddingVertical: 15,
      paddingHorizontal: 18,
      alignItems: 'center',
      justifyContent: 'center',
    },
    btnGhost: { backgroundColor: 'transparent', borderWidth: 1.5, borderColor: C.primaryText },
    btnIn: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    btnIc: { fontSize: 16 },
    btnTx: { color: C.onPrimary, fontWeight: '700', fontSize: 16 },
    err: { backgroundColor: C.badBg, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: C.badLine },
    okBox: { backgroundColor: C.okBg, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: C.okLine },
    hint: { color: C.mute, textAlign: 'center' },
    opt: { padding: 13, borderRadius: 12, borderWidth: 1, borderColor: C.line, backgroundColor: C.field },
    optOn: { backgroundColor: C.primary, borderColor: C.primary },
    cam: { height: 300, borderRadius: 16, overflow: 'hidden', backgroundColor: '#000', borderWidth: 1, borderColor: C.line },
  });
