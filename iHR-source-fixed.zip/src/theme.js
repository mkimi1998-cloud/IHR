// Palette taken from the original iHR screen: warm grey, terracotta buttons, card-color yellow, navy text.
// Two palettes: `light` and `dark`. The app picks one from the phone's system theme.
export const light = {
  bg: '#EEEDEE',
  card: '#FFFFFF',
  line: '#D9D5D7',
  ink: '#14141A',
  mute: '#6B6B75',
  field: '#FAF9FA',
  primary: '#BC4A32',
  primaryText: '#BC4A32',
  primarySoft: '#F6E4DF',
  onPrimary: '#FFFFFF',
  accent: '#FDC107',
  navy: '#1F2D55',
  pill: '#CDD3DB',
  ok: '#2E7D4F',
  okBg: '#E5F3EA',
  okLine: '#BFE0CB',
  bad: '#B3261E',
  badBg: '#FBE9E7',
  badLine: '#F2C6C1',
};

export const dark = {
  bg: '#121214',
  card: '#1D1D21',
  line: '#34343B',
  ink: '#F2F2F5',
  mute: '#A3A3AE',
  field: '#26262B',
  primary: '#C4513A',
  primaryText: '#FF8F75',
  primarySoft: '#3A2420',
  onPrimary: '#FFFFFF',
  accent: '#FDC107',
  navy: '#A9BBEA',
  pill: '#2B3245',
  ok: '#7FD6A0',
  okBg: '#16301F',
  okLine: '#2C5A40',
  bad: '#FFB4AB',
  badBg: '#3C1F1D',
  badLine: '#6B2E2A',
};

export const themes = { light, dark };
